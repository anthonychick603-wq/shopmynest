<?php

defined( 'ABSPATH' ) || exit;

final class MNU_Install {
    private static bool $initialized = false;

    /**
     * Register lifecycle callbacks that must run at or after WordPress init.
     */
    public static function init(): void {
        if ( self::$initialized ) {
            return;
        }

        self::$initialized = true;
        add_action( 'init', array( __CLASS__, 'maybe_flush_rewrite_rules' ), 99 );
    }

    /**
     * Install or update persistent marketplace data.
     *
     * Custom post types are never registered from plugins_loaded. WordPress 7
     * initializes the rewrite object later in the request, so registering a
     * rewritable post type too early can call add_rewrite_tag() on a null
     * $wp_rewrite object and take the site down.
     */
    public static function activate(): void {
        self::create_roles();
        self::create_tables();
        self::create_pages();
        self::set_defaults();
        if ( class_exists( 'MNU_Buyer_Experience' ) ) {
            MNU_Buyer_Experience::configure_accounts();
        }

        // Rewrite rules are flushed once, only after init and CPT registration.
        update_option( 'mnu_flush_rewrite_rules', 'yes', false );

        if ( ! wp_next_scheduled( 'tnm_daily_maintenance' ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'tnm_daily_maintenance' );
        }

        /*
         * Plugin activation happens after init in wp-admin. In that specific
         * request, it is safe to register the post types and perform the one-time
         * flush immediately. Normal boot upgrades remain deferred until init.
         */
        if ( did_action( 'init' ) ) {
            self::maybe_flush_rewrite_rules();
        }
    }

    public static function deactivate(): void {
        wp_clear_scheduled_hook( 'tnm_daily_maintenance' );

        // Avoid calling the rewrite API if WordPress has not initialized it.
        global $wp_rewrite;
        if ( did_action( 'init' ) && is_object( $wp_rewrite ) ) {
            flush_rewrite_rules( false );
        }
    }

    /**
     * Register the marketplace CPTs and flush rewrite rules at a safe point.
     */
    public static function maybe_flush_rewrite_rules(): void {
        if ( 'yes' !== get_option( 'mnu_flush_rewrite_rules', '' ) ) {
            return;
        }

        if ( ! did_action( 'init' ) ) {
            return;
        }

        if ( class_exists( 'TNM_Content' ) ) {
            TNM_Content::register_post_types();
        }

        global $wp_rewrite;
        if ( ! is_object( $wp_rewrite ) ) {
            // Keep the pending flag so a later normal request can retry safely.
            return;
        }

        flush_rewrite_rules( false );
        delete_option( 'mnu_flush_rewrite_rules' );
    }

    public static function set_defaults(): void {
        $defaults = array(
            'fee_percent'              => 8,
            'fee_label'                => 'Nest Service Fee',
            'holding_days'             => 7,
            'minimum_payout'           => 25,
            'automatic_payouts'        => 'no',
            'payout_schedule'          => 'weekly',
            'payout_method'            => 'manual',
            'paypal_environment'       => 'sandbox',
            'paypal_client_id'         => '',
            'paypal_client_secret'     => '',
            'seller_can_publish'       => 'yes',
            'require_application'      => 'yes',
            'verified_reviews_only'    => 'yes',
            'allow_buyer_registration' => 'yes',
            'token_lifetime_days'      => 30,
            'buyer_sees_seller_fee'    => 'no',
            'order_breakdown_emails'   => 'yes',
            'remove_local_pickup'      => 'yes',
            'seller_order_emails'      => 'yes',
        );
        $current = get_option( 'tnm_settings', array() );
        update_option( 'tnm_settings', wp_parse_args( is_array( $current ) ? $current : array(), $defaults ), false );
        update_option( 'tnm_db_version', MNU_DB_VERSION, false );
        update_option( 'mnu_version', MNU_VERSION, false );
    }

    public static function create_roles(): void {
        $seller_caps = array(
            'read'                      => true,
            'upload_files'              => true,
            'edit_posts'                => true,
            'publish_posts'             => true,
            'delete_posts'              => true,
            'edit_published_posts'      => true,
            'delete_published_posts'    => true,
            'edit_products'             => true,
            'publish_products'          => true,
            'read_private_products'     => true,
            'delete_products'           => true,
            'edit_published_products'   => true,
            'delete_published_products' => true,
            'tnm_manage_store'          => true,
            'tnm_view_earnings'         => true,
            'tnm_request_payout'        => true,
        );

        foreach ( array( 'tnm_seller' => 'Nest Seller', 'mynest_seller' => 'MyNest Seller' ) as $role_key => $role_name ) {
            if ( ! get_role( $role_key ) ) {
                add_role( $role_key, __( $role_name, 'mynest-unified-marketplace' ), $seller_caps );
            }
            $role = get_role( $role_key );
            if ( $role ) {
                foreach ( $seller_caps as $cap => $grant ) {
                    $role->add_cap( $cap, $grant );
                }
            }
        }

        $admin = get_role( 'administrator' );
        if ( $admin ) {
            foreach ( array( 'tnm_manage_marketplace', 'tnm_manage_store', 'tnm_view_earnings', 'tnm_request_payout', 'mnu_manage_marketplace' ) as $cap ) {
                $admin->add_cap( $cap );
            }
        }

        $manager = get_role( 'shop_manager' );
        if ( $manager ) {
            foreach ( array( 'tnm_manage_marketplace', 'mnu_manage_marketplace' ) as $cap ) {
                $manager->add_cap( $cap );
            }
        }
    }

    public static function create_tables(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset = $wpdb->get_charset_collate();

        $queries = array();
        $queries[] = 'CREATE TABLE ' . tnm_table( 'ledger' ) . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            seller_id bigint(20) unsigned NOT NULL,
            order_id bigint(20) unsigned NOT NULL,
            order_item_id bigint(20) unsigned NOT NULL DEFAULT 0,
            type varchar(30) NOT NULL DEFAULT 'earning',
            gross decimal(18,6) NOT NULL DEFAULT 0,
            platform_fee decimal(18,6) NOT NULL DEFAULT 0,
            tax decimal(18,6) NOT NULL DEFAULT 0,
            shipping decimal(18,6) NOT NULL DEFAULT 0,
            net decimal(18,6) NOT NULL DEFAULT 0,
            currency varchar(10) NOT NULL DEFAULT 'USD',
            status varchar(30) NOT NULL DEFAULT 'pending',
            available_at datetime NULL,
            payout_id bigint(20) unsigned NOT NULL DEFAULT 0,
            platform_payout_id varchar(190) NOT NULL DEFAULT '',
            stripe_transfer_id varchar(190) NOT NULL DEFAULT '',
            note text NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY order_item_type (order_id,order_item_id,type),
            KEY seller_status (seller_id,status),
            KEY payout_id (payout_id),
            KEY platform_payout (platform_payout_id),
            KEY stripe_transfer (stripe_transfer_id)
        ) $charset;";

        $queries[] = 'CREATE TABLE ' . tnm_table( 'payouts' ) . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            seller_id bigint(20) unsigned NOT NULL,
            amount decimal(18,6) NOT NULL DEFAULT 0,
            currency varchar(10) NOT NULL DEFAULT 'USD',
            method varchar(30) NOT NULL DEFAULT 'manual',
            destination varchar(190) NOT NULL DEFAULT '',
            external_id varchar(190) NOT NULL DEFAULT '',
            status varchar(30) NOT NULL DEFAULT 'requested',
            notes text NULL,
            requested_at datetime NOT NULL,
            processed_at datetime NULL,
            PRIMARY KEY  (id),
            KEY seller_status (seller_id,status)
        ) $charset;";

        $queries[] = 'CREATE TABLE ' . tnm_table( 'follows' ) . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            follower_id bigint(20) unsigned NOT NULL,
            following_id bigint(20) unsigned NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY follower_following (follower_id,following_id),
            KEY following_id (following_id)
        ) $charset;";

        $queries[] = 'CREATE TABLE ' . tnm_table( 'notifications' ) . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            user_id bigint(20) unsigned NOT NULL,
            actor_id bigint(20) unsigned NOT NULL DEFAULT 0,
            type varchar(50) NOT NULL,
            object_id bigint(20) unsigned NOT NULL DEFAULT 0,
            object_type varchar(50) NOT NULL DEFAULT '',
            title varchar(255) NOT NULL,
            message text NULL,
            url text NULL,
            is_read tinyint(1) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY user_read (user_id,is_read),
            KEY created_at (created_at)
        ) $charset;";

        $queries[] = 'CREATE TABLE ' . tnm_table( 'messages' ) . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            sender_id bigint(20) unsigned NOT NULL,
            recipient_id bigint(20) unsigned NOT NULL,
            message text NOT NULL,
            is_read tinyint(1) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY conversation_a (sender_id,recipient_id,created_at),
            KEY conversation_b (recipient_id,sender_id,created_at),
            KEY recipient_read (recipient_id,is_read)
        ) $charset;";

        $queries[] = 'CREATE TABLE ' . tnm_table( 'reviews' ) . " (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            reviewer_id bigint(20) unsigned NOT NULL,
            seller_id bigint(20) unsigned NOT NULL,
            order_id bigint(20) unsigned NOT NULL,
            rating tinyint(2) unsigned NOT NULL,
            review text NULL,
            status varchar(20) NOT NULL DEFAULT 'approved',
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY reviewer_seller_order (reviewer_id,seller_id,order_id),
            KEY seller_status (seller_id,status)
        ) $charset;";

        global $wpdb;
        $queries[] = 'CREATE TABLE ' . $wpdb->prefix . "mnu_import_jobs (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            seller_id bigint(20) unsigned NOT NULL,
            status varchar(20) NOT NULL DEFAULT 'ready',
            total_rows int(11) unsigned NOT NULL DEFAULT 0,
            processed int(11) unsigned NOT NULL DEFAULT 0,
            created int(11) unsigned NOT NULL DEFAULT 0,
            updated int(11) unsigned NOT NULL DEFAULT 0,
            failed int(11) unsigned NOT NULL DEFAULT 0,
            columns_json longtext NULL,
            rows_json longtext NULL,
            errors_json longtext NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY seller_status (seller_id,status)
        ) $charset;";

        foreach ( $queries as $query ) {
            dbDelta( $query );
        }
    }

    public static function create_pages(): void {
        $pages = array(
            'feed' => array( 'title' => 'Nest Feed', 'slug' => 'nest-feed', 'content' => '[the_nest_feed]' ),
            'browse' => array( 'title' => 'Browse', 'slug' => 'browse', 'content' => '[mynest_browse]' ),
            'create' => array( 'title' => 'Create', 'slug' => 'create', 'content' => '[mynest_create_hub]' ),
            'notifications' => array( 'title' => 'Notifications', 'slug' => 'notifications', 'content' => '[mynest_notifications]' ),
            'profile' => array( 'title' => 'Profile', 'slug' => 'profile', 'content' => '[mynest_profile]' ),
            'become_seller' => array( 'title' => 'Become a Seller', 'slug' => 'become-a-seller', 'content' => '[mynest_become_seller]' ),
            'seller_application' => array( 'title' => 'Seller Application', 'slug' => 'seller-application', 'content' => '[mynest_seller_application]' ),
            'seller_login' => array( 'title' => 'Seller Login', 'slug' => 'seller-login', 'content' => '[mynest_seller_login]' ),
            'seller_dashboard' => array( 'title' => 'Seller Dashboard', 'slug' => 'seller-dashboard', 'content' => '[the_nest_seller_dashboard]' ),
            'seller_orders' => array( 'title' => 'Seller Orders', 'slug' => 'seller-orders', 'content' => '[mynest_seller_orders]' ),
            'seller_order' => array( 'title' => 'Seller Order', 'slug' => 'seller-order', 'content' => '[mynest_seller_order]' ),
            'seller_add_product' => array( 'title' => 'Add Product', 'slug' => 'seller-add-product', 'content' => '[mynest_seller_add_product]' ),
            'create_blog' => array( 'title' => 'Create Blog Post', 'slug' => 'create-blog', 'content' => '[mynest_create_blog]' ),
            'my_purchases' => array( 'title' => 'My Purchases', 'slug' => 'my-purchases', 'content' => '[mynest_my_purchases]' ),
            'reviews' => array( 'title' => 'Reviews', 'slug' => 'reviews', 'content' => '[mynest_reviews]' ),
            'seller_payouts' => array( 'title' => 'Seller Earnings', 'slug' => 'seller-payouts', 'content' => '[mynest_seller_payouts]' ),
            'shop' => array( 'title' => 'Shop', 'slug' => 'shop', 'content' => '' ),
            'cart' => array( 'title' => 'Cart', 'slug' => 'cart', 'content' => '[woocommerce_cart]' ),
            'checkout' => array( 'title' => 'Checkout', 'slug' => 'checkout', 'content' => '[woocommerce_checkout]' ),
            'my_account' => array( 'title' => 'My Account', 'slug' => 'my-account', 'content' => '[woocommerce_my_account]' ),
            'seller_terms' => array( 'title' => 'Seller Terms', 'slug' => 'seller-terms', 'content' => '<h2>MyNest Seller Terms</h2><p>Replace this starter text with your reviewed seller agreement before launch.</p>' ),
            'privacy_policy' => array( 'title' => 'Privacy Policy', 'slug' => 'privacy-policy', 'content' => '<h2>Privacy Policy</h2><p>Replace this starter text with a privacy policy reviewed for your marketplace, mobile app, payment processors, and jurisdiction.</p>' ),
            'terms' => array( 'title' => 'Terms of Service', 'slug' => 'terms-of-service', 'content' => '<h2>Terms of Service</h2><p>Replace this starter text with your reviewed marketplace terms before launch.</p>' ),
            'refund_policy' => array( 'title' => 'Refund Policy', 'slug' => 'refund-policy', 'content' => '<h2>Refund Policy</h2><p>Replace this starter text with your reviewed refund and dispute policy before launch.</p>' ),
        );

        foreach ( $pages as $key => $page ) {
            $existing = (int) get_option( 'tnm_page_' . $key, 0 );
            if ( $existing && 'trash' !== get_post_status( $existing ) ) {
                continue;
            }

            $found = get_page_by_path( $page['slug'] );
            if ( $found ) {
                update_option( 'tnm_page_' . $key, (int) $found->ID, false );
                continue;
            }

            $page_id = wp_insert_post(
                array(
                    'post_title'   => $page['title'],
                    'post_name'    => $page['slug'],
                    'post_content' => $page['content'],
                    'post_status'  => 'publish',
                    'post_type'    => 'page',
                ),
                true
            );
            if ( ! is_wp_error( $page_id ) ) {
                update_option( 'tnm_page_' . $key, (int) $page_id, false );
            }
        }

        $woocommerce_pages = array(
            'woocommerce_shop_page_id'      => 'shop',
            'woocommerce_cart_page_id'      => 'cart',
            'woocommerce_checkout_page_id'  => 'checkout',
            'woocommerce_myaccount_page_id' => 'my_account',
        );
        foreach ( $woocommerce_pages as $option => $key ) {
            if ( ! (int) get_option( $option, 0 ) ) {
                update_option( $option, (int) get_option( 'tnm_page_' . $key, 0 ), false );
            }
        }

        if ( ! (int) get_option( 'wp_page_for_privacy_policy', 0 ) ) {
            update_option( 'wp_page_for_privacy_policy', (int) get_option( 'tnm_page_privacy_policy', 0 ), false );
        }
    }
}
